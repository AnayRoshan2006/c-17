var play=1;
var end=0;
var gameState=play;

var monkey , monkey_running;
var banana ,bananaImage, obstacle, obstacleImage;
var FoodGroup, obstacleGroup,invisibleground;
var score=0;

function preload(){
  
  
  monkey_running=loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png");
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas(600, 200);
  
  monkey = createSprite(50,160,20,50);
  monkey.addAnimation("running", monkey_running);
  

  monkey.scale = 0.1;
  
  ground = createSprite(200,180,600,10);
   ground.x = ground.width/2;
  
  invisibleGround = createSprite(200,190,400,10);
  invisibleGround.visible = false;
 
  
  
  //create Obstacle and Cloud Groups
  obstacleGroup = new Group();
  FoodGroup = new Group(); 

  
}


function draw() {
background("white");
  text("survival score "+score,300,10);
  monkey.collide(ground);
  if(gameState === play){
    
     if(keyDown("space")&& monkey.y >= 100) {
        monkey.velocityY = -13;
   }
     if(FoodGroup.isTouching(monkey)){
     score=score+1;
   FoodGroup.destroyEach();
}
    spawnObstacles();
  spawnFood();
    if(obstacleGroup.isTouching(monkey)){
     gameState = end ;
}
  }
  else if (gameState === end) {
     
      
      monkey.velocityY = 0
      textSize(30);
     text("gameover",250,100);
      //set lifetime of the game objects so that they are never destroyed
    obstacleGroup.setLifetimeEach(-1);
    FoodGroup.setLifetimeEach(-1);
     
     obstacleGroup.setVelocityXEach(0);
     FoodGroup.setVelocityXEach(0);    
   }
   
  monkey.debug = true;

  
  
  
  
  
  monkey.velocityY = monkey.velocityY + 1
   
  
  drawSprites();
}

function spawnObstacles(){
 if (frameCount % 90 === 0){
   var obstacle = createSprite(600,155,10,40);
  obstacle.addImage(obstacleImage);
   obstacle.scale=0.11;
   obstacle.velocityX = -(6 + score/7);
   obstacle.setCollider("rectangle",0,0,450,450);
 obstacleGroup.add(obstacle);
  
 }
}
function spawnFood(){
if (frameCount % 90 === 0){
  var food = createSprite(600,120,40,10);
    food.y = Math.round(random(40,100));
  food.addImage(bananaImage);
   food.scale=0.1;
   food.velocityX = -(6 + score/7);
 FoodGroup.add(food);
  
 }
}
